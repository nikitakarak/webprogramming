from django.views import generic
from django.shortcuts import render
from .models import Player, Club, Team


def index(request):
	return render(request, 'index.html')


class PlayersListView(generic.ListView):
	model = Player


class PlayersDetailView(generic.DetailView):
	model = Player


class ClubsListView(generic.ListView):
	model = Club


class ClubsDetailView(generic.DetailView):
	model = Club


class TeamsListView(generic.ListView):
	model = Team


class TeamsDetailView(generic.DetailView):
	model = Team
