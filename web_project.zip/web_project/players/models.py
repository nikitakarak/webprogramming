from django.db import models
from django.urls import reverse


class Player(models.Model):
    id = models.IntegerField(primary_key=True)
    name_player = models.CharField(max_length=100, blank=False)
    patronymic_player = models.CharField(max_length=100, blank=False)
    surname_player = models.CharField(max_length=100, blank=False)
    biography_player = models.TextField(max_length=10000, null=True)

    date_of_birth_player = models.CharField(max_length=100, blank=False)

    class Meta:
        ordering = ['name_player', 'surname_player']

    def get_absolute_url_player(self):
        return reverse('players-detail', args=[str(self.id)])

    def __str__(self):
        return f'{self.name_player}, {self.surname_player}'


class Club(models.Model):
    id = models.IntegerField(primary_key=True)
    club_name = models.CharField(max_length=100, blank=False)
    club_biography = models.CharField(max_length=10000, blank=False)
    # players_club = models.CharField(max_length=100, blank=False)

    class Meta:
        ordering = ['club_name']

    def get_absolute_url_club(self):
        return reverse('clubs-detail', args=[str(self.id)])

    def __str__(self):
        return self.club_name


class Team(models.Model):
    id = models.IntegerField(primary_key=True)
    team_name = models.CharField(max_length=200, blank=False)
    team_biography = models.CharField(max_length=10000, blank=False)
    # players_team = models.CharField(max_length=200, blank=False)

    class Meta:
        ordering = ['team_name']

    def get_absolute_url_team(self):
        return reverse('teams-detail', args=[str(self.id)])

    def __str__(self):
        return self.team_name


class PlayerClub(models.Model):
    player_id = models.ManyToManyField(Player)
    club_id = models.ManyToManyField(Club)
    dates_play = models.TextField(max_length=1000, null=True)

    def get_absolute_url_player_club(self):
        return reverse('player_club-detail', args=[str(self.player_id)])

    def __str__(self):
        return f'{self.player.name_player} {self.player.surname_player} {self.club.name_club}'


class PlayerTeam(models.Model):
    player_id = models.ManyToManyField(Player)
    team_id = models.ManyToManyField(Team)
    dates_play = models.TextField(max_length=1000, null=True)

    def get_absolute_url_player_team(self):
        return reverse('player_team-detail', args=[str(self.id)])

    def __str__(self):
        return f'{self.player.name_player} {self.player.surname_player} {self.team.name_team}'
