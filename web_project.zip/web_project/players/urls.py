from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name='index'),
    path('players', views.PlayersListView.as_view(), name='players'),
    path('players/<int:pk>', views.PlayersDetailView.as_view(), name='players-detail'),
    path('clubs', views.ClubsListView.as_view(), name='clubs'),
    path('clubs/<int:pk>', views.ClubsDetailView.as_view(), name='clubs-detail'),
    path('teams', views.TeamsListView.as_view(), name='teams'),
    path('teams/<int:pk>', views.TeamsDetailView.as_view(), name='teams-detail'),
]
