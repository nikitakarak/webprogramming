-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Май 30 2022 г., 22:09
-- Версия сервера: 10.4.24-MariaDB
-- Версия PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `volleyball`
--

-- --------------------------------------------------------

--
-- Структура таблицы `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add player', 7, 'add_player'),
(26, 'Can change player', 7, 'change_player'),
(27, 'Can delete player', 7, 'delete_player'),
(28, 'Can view player', 7, 'view_player'),
(29, 'Can add club', 8, 'add_club'),
(30, 'Can change club', 8, 'change_club'),
(31, 'Can delete club', 8, 'delete_club'),
(32, 'Can view club', 8, 'view_club'),
(33, 'Can add team', 9, 'add_team'),
(34, 'Can change team', 9, 'change_team'),
(35, 'Can delete team', 9, 'delete_team'),
(36, 'Can view team', 9, 'view_team'),
(37, 'Can add player_club', 10, 'add_player_club'),
(38, 'Can change player_club', 10, 'change_player_club'),
(39, 'Can delete player_club', 10, 'delete_player_club'),
(40, 'Can view player_club', 10, 'view_player_club'),
(41, 'Can add player_team', 11, 'add_player_team'),
(42, 'Can change player_team', 11, 'change_player_team'),
(43, 'Can delete player_team', 11, 'delete_player_team'),
(44, 'Can view player_team', 11, 'view_player_team');

-- --------------------------------------------------------

--
-- Структура таблицы `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(8, 'players_catalog', 'club'),
(7, 'players_catalog', 'player'),
(10, 'players_catalog', 'player_club'),
(11, 'players_catalog', 'player_team'),
(9, 'players_catalog', 'team'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Структура таблицы `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2022-05-23 16:28:08.572390'),
(2, 'auth', '0001_initial', '2022-05-23 16:28:10.095343'),
(3, 'admin', '0001_initial', '2022-05-23 16:28:10.279806'),
(4, 'admin', '0002_logentry_remove_auto_add', '2022-05-23 16:28:10.290737'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2022-05-23 16:28:10.303706'),
(6, 'contenttypes', '0002_remove_content_type_name', '2022-05-23 16:28:10.384583'),
(7, 'auth', '0002_alter_permission_name_max_length', '2022-05-23 16:28:10.463541'),
(8, 'auth', '0003_alter_user_email_max_length', '2022-05-23 16:28:10.484486'),
(9, 'auth', '0004_alter_user_username_opts', '2022-05-23 16:28:10.494689'),
(10, 'auth', '0005_alter_user_last_login_null', '2022-05-23 16:28:10.556281'),
(11, 'auth', '0006_require_contenttypes_0002', '2022-05-23 16:28:10.568146'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2022-05-23 16:28:10.578688'),
(13, 'auth', '0008_alter_user_username_max_length', '2022-05-23 16:28:10.596143'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2022-05-23 16:28:10.703914'),
(15, 'auth', '0010_alter_group_name_max_length', '2022-05-23 16:28:10.725854'),
(16, 'auth', '0011_update_proxy_permissions', '2022-05-23 16:28:10.738829'),
(17, 'auth', '0012_alter_user_first_name_max_length', '2022-05-23 16:28:10.771439'),
(18, 'sessions', '0001_initial', '2022-05-23 16:28:10.837331');

-- --------------------------------------------------------

--
-- Структура таблицы `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `players_club`
--

CREATE TABLE `players_club` (
  `id` int(11) NOT NULL,
  `club_name` varchar(50) DEFAULT NULL,
  `club_biography` varchar(10000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `players_club`
--

INSERT INTO `players_club` (`id`, `club_name`, `club_biography`) VALUES
(1, 'Динамо Москва', '«Динамо» (Москва) — советский и российский мужской волейбольный клуб. Основан в 1926 году, девятикратный чемпион России и СССР'),
(2, 'Зенит Санкт-Петербург', '«Зенит» — российский мужской волейбольный клуб из города Санкт-Петербурга. Волейбольная команда «Зенит» была образована летом 2017 года и начиная с сезона 2017/2018 выступает в Российской Суперлиге. В своём первом же сезоне клуб занял 2 место в чемпионате и играл в финале Кубка. ');

-- --------------------------------------------------------

--
-- Структура таблицы `players_club_players`
--

CREATE TABLE `players_club_players` (
  `players` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура таблицы `players_player`
--

CREATE TABLE `players_player` (
  `id` int(50) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `date_of_birth_player` date DEFAULT NULL,
  `biography_player` varchar(10000) DEFAULT NULL,
  `club` varchar(50) DEFAULT NULL,
  `nationality` varchar(50) DEFAULT NULL,
  `trophies` text DEFAULT NULL,
  `name_player` varchar(100) DEFAULT NULL,
  `patronymic_player` varchar(100) DEFAULT NULL,
  `surname_player` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `players_player`
--

INSERT INTO `players_player` (`id`, `position`, `date_of_birth_player`, `biography_player`, `club`, `nationality`, `trophies`, `name_player`, `patronymic_player`, `surname_player`) VALUES
(1, 'Доигровщик', '0000-00-00', 'Егор Клюка родился в Кобрине в семье легкоатлетов. В октябре 2010 года Егор Клюка дебютировал в высшей лиге чемпионата Белоруссии в составе команды «Западный Буг» (Брест). Осенью 2014 года Егор Клюка вместе с другими лидерами молодёжной команды, Дмитрием Волковым и Ильёй Власовым, был переведён в основной состав и сразу попал в стартовую шестёрку «Факела». По итогам дебютного сезона в Суперлиге все трое 19-летних волейболистов получили приглашение во вторую сборную России и в июне 2015 года выиграли бронзу на Европейских играх в Баку. В продолжение сезона Егор завоевал золотые медали на Универсиаде в Кванджу и чемпионате мира U23 в Дубае, где был признан самым ценным игроком. После завершения клубного сезона-2019/20 объявил о переходе из «Факела» в петербургский «Зенит», в его составе в наступившем сезоне выиграл серебряные медали Кубка России, чемпионата страны и Кубка Европейской конфедерации волейбола.\r\nВ 2021 году завоевал серебряную медаль Олимпийских игр в Токио, был включён в символическую сборную турнира.', 'Зенит Санкт-Петербург', 'Россия', 'Олимпийские игры\r\nСеребро	Токио 2020\r\nЧемпионат Европы\r\nЗолото	Краков 2017\r\nЛига наций\r\nЗолото	Вильнёв-д’Аск 2018\r\nЗолото	Чикаго 2019\r\nУниверсиады\r\nЗолото Кванджу 2015\r\nЕвропейские игры\r\nБронза	Баку 2015', 'Егор', 'Васильевич', 'Клюка'),
(2, 'Связующий', '0000-00-00', 'Российский волейболист, связующий питерского «Зенита» и сборной России, участник Олимпийских игр 2016 года. Заслуженный мастер спорта России (2021).', 'Зенит Санкт-Петербург', 'Россия', '2009 — бронзовый призёр чемпионата Европы среди юниоров\r\n2012 — лучший игрок Кубка Молодежной лиги\r\n2013 — чемпион России\r\n2014 — чемпион России, обладатель Кубка России\r\n2015 — чемпион России, обладатель Суперкубка России, победитель Лиги чемпионов, серебряный призёр Клубного чемпионата мира, бронзовый призёр Европейских игр\r\n2016 — чемпион России, победитель Лиги чемпионов, полуфиналист Олимпийских игр\r\n2017 — чемпион России, победитель Лиги чемпионов\r\n2018 — обладатель Кубка Сибири и Дальнего Востока, победитель Лиги наций\r\n2019 — чемпион России, обладатель Суперкубка России, победитель Лиги наций\r\n2020 — бронзовый призёр чемпионата России\r\n2021 — серебряный призёр Олимпийских игр в Токио', 'Игорь', 'Андреевич', 'Кобзарь'),
(3, 'Павел Панков', '0000-00-00', 'Павел Вадимович Панков (род. 14 августа 1995, Москва) — российский волейболист, связующий московского «Динамо». Заслуженный мастер спорта России (2021). В сезоне-2016/17 Павел Панков выступал за кемеровский «Кузбасс», где составил пару связующих с опытным Сергеем Макаровым и получил большую игровую практику, а в межсезонье перешёл в «Зенит» из Санкт-Петербурга. 3 июня 2017 года в Казани дебютировал в составе национальной сборной России в матче Мировой лиги против команды Франции.\r\n\r\nВ сезоне-2017/18 вместе с петербургским «Зенитом» выиграл серебро чемпионата России и к тому же стал самым результативным игроком Суперлиги среди связующих, а по количеству эйсов (74) уступил только Вильфредо Леону. Панков вновь вошёл в заявку сборной России, но не провёл в Лиге наций ни одного матча из-за травмы плеча. В июне 2019 года вернулся в московское «Динамо», осенью того же года стал капитаном команды. В сезоне-2020/21 выиграл Кубок России, Кубок Европейской конфедерации волейбола, золото российской Суперлиги и признавался самым ценным игроком по итогам каждого из этих турниров.\r\n\r\nВ 2021 году вернулся в состав российской сборной и стал серебряным призёром Олимпийских игр в Токио.', 'Динамо Москва', 'Россия', 'Волейбол\r\nОлимпийские игры\r\nСеребро	Токио 2020\r\nУниверсиады\r\nЗолото	Кванджу 2015\r\nБронза	Неаполь 2019', 'Павел', '', 'Панков'),
(4, 'Диагональный', '0000-00-00', 'Фёдор Владимирович Воронков (род. 10 декабря 1995 года) — российский волейболист, доигровщик петербургского «Зенита». Мастер спорта. ', 'Зенит Санкт-Петербург', 'Россия', 'Лига наций\r\nЗолото	Чикаго 2019', 'Фёдор', 'Владимирович', 'Воронков'),
(5, 'Либеро', '0000-00-00', 'Евгений Александрович Баранов (род. 30 июня 1995 года, Архангельск) — российский волейболист, либеро клуба «Динамо» (Москва) и сборной России. Мастер спорта. С 2018 года выступает за основную команду «Динамо» (Москва).\r\nС 2021 года призывается в сборную России.', 'Динамо Москва', 'Россия', 'Чемпион России 2021 г.\r\nОбладатель Кубка России 2020 г.\r\nПобедитель Кубка ЕКВ 2021 г.\r\nСеребряный призер Чемпионата России 2016 г.\r\nЧемпион молодежной лиги 2017 г.\r\nПобедитель Кубка молодежной лиги 2018 г.\r\nСеребряный призер Кубка молодежной Лиги 2015, 2017 г.\r\nБронзовый призер Кубка Победы 2015 г.\r\nИндивидуальные призы\r\nЛучший либеро Суперлиги сезона 2020/21\r\nЛучший либеро сезона 2015 среди молодежных команд', 'Евгений', 'Александрович', 'Баранов');

-- --------------------------------------------------------

--
-- Структура таблицы `players_team`
--

CREATE TABLE `players_team` (
  `id` int(11) NOT NULL,
  `team_name` varchar(100) DEFAULT NULL,
  `team_biography` varchar(10000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `players_team`
--

INSERT INTO `players_team` (`id`, `team_name`, `team_biography`) VALUES
(1, 'Россия', 'Мужская национальная сборная России по волейболу — правопреемница сборной СССР — представляет Россию на международных соревнованиях по волейболу. Впервые была собрана в 1992 году, в официальных международных соревнованиях участвует с 1993 года. Управляется Всероссийской федерацией волейбола. Чемпион Олимпийских игр в Лондоне (2012), чемпион Европы (2013, 2017), 3-кратный победитель Мировой лиги (2002, 2011 и 2013)'),
(2, 'Бразилия', 'Мужская сборная Бразилии по волейболу — национальная команда, представляющая Бразилию на международных соревнованиях по волейболу. Управляется Бразильской конфедерацией волейбола (CBV, образована в 1954 году). Трёхкратный олимпийский чемпион. Занимает первое место в текущем рейтинге Международной федерации волейбола.  ');

-- --------------------------------------------------------

--
-- Структура таблицы `players_team_players`
--

CREATE TABLE `players_team_players` (
  `players` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Индексы таблицы `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Индексы таблицы `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Индексы таблицы `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Индексы таблицы `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Индексы таблицы `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Индексы таблицы `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Индексы таблицы `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT для таблицы `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Ограничения внешнего ключа таблицы `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Ограничения внешнего ключа таблицы `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Ограничения внешнего ключа таблицы `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Ограничения внешнего ключа таблицы `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
